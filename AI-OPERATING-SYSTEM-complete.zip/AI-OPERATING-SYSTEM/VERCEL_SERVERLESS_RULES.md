# Vercel Serverless Rules

Dokumen ini melengkapi baseline infra untuk project yang berjalan di Vercel.

## 1. Runtime Mindset

- Anggap Vercel Functions stateless dan ephemeral.
- Jangan bergantung pada filesystem lokal untuk data yang harus bertahan.
- Jangan memperbaiki schema, membuat tabel, atau menulis state durable di request path.
- Semua state durable harus hidup di database, blob storage, queue, atau service eksternal yang memang dibuat untuk itu.

## 2. Storage

- File upload tidak boleh dianggap aman bila hanya disimpan di local filesystem function.
- Gunakan storage yang durable seperti Vercel Blob atau object storage lain.
- Simpan metadata file di database, bukan isi file mentah.

## 3. Environment

- Pisahkan `local`, `preview` atau `staging`, dan `production`.
- Secret hanya boleh hidup di env manager yang aman.
- Jangan commit secret ke repo.
- Jangan expose secret lewat `NEXT_PUBLIC_*` atau response API.

## 4. Health dan Debug

- Health endpoint publik hanya boleh mengembalikan status minimum.
- Jangan bocorkan host database, username pattern, hint credential, atau stack detail di endpoint health publik.
- Debug route sementara harus dihapus atau diproteksi sebelum deploy.

## 5. Database dan Migration

- Migration harus dijalankan sebagai langkah release terpisah, bukan diam-diam saat request masuk.
- Jangan membuat tabel atau kolom dari service runtime.
- Schema drift harus diselesaikan di migration plan, bukan dengan fallback permanen di production code.

## 6. Region dan Latency

- Pilih region function dekat dengan database utama.
- Hindari roundtrip lintas region untuk flow yang sering dipakai.
- Jika ada job berat atau integrasi lambat, pertimbangkan queue atau background step.

## 7. Caching

- Cache dipakai untuk read optimization, bukan sumber kebenaran utama.
- Tentukan key, TTL, dan invalidation strategy secara eksplisit.
- Jangan meng-cache response yang mengandung data sensitif lintas user tanpa scope yang aman.

## 8. Async Work

- Untuk kerja pasca-response, gunakan mekanisme yang memang aman untuk serverless.
- Jangan mengandalkan proses background in-memory yang mungkin mati kapan saja.
- Job penting harus idempotent.

## 9. Cron dan Schedules

- Semua cron harus didokumentasikan:
  - tujuan
  - URL target
  - auth atau protection
  - timezone
  - dampak jika gagal
- Cron production harus aman dipanggil berulang.

## 10. Deployment Protection

- Preview dan production yang diproteksi harus tetap punya jalur health atau smoke test yang aman.
- Jika memakai bypass secret, kelola seperti secret sensitif lain.

## 11. Observability

- Minimal ada:
  - health check
  - application log
  - audit log untuk aksi sensitif
  - error alert
  - visibility terhadap job atau queue failure
- Tambahkan request correlation ID bila flow mulai kompleks.

## 12. Release Rules

- Setiap deploy harus terkait commit atau artifact yang jelas.
- Perubahan high risk jangan dibundel terlalu banyak.
- Perubahan schema, auth, payment, export, dan upload harus punya rollback atau roll-forward plan.

## 13. Red Flags

- membuat tabel di request handler
- simpan file penting di `/tmp` lalu menganggapnya permanen
- health endpoint membocorkan detail internal
- runtime production memperbaiki env atau schema sendiri
- background work bergantung pada proses function tetap hidup
